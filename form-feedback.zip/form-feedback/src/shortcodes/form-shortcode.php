<?php

add_shortcode('fbfSortcode', function(){
    include dirname(__FILE__) . "/../templates/form_view.php";
});