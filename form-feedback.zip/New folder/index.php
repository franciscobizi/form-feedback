<?php

// silence is gold